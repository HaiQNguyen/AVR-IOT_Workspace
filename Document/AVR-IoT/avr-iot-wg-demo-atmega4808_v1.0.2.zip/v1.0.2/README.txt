CHECK IF YOUR FIRMWARE IS UP TO DATE: 
1. Open your file explorer and navigate to the CURIOSITY drive
2. Open the file KIT-INFO.TXT to view your current firmware version 

UPDATE YOUR FIRMWARE:
1. Drag and Drop the firmware update .hex file into your CURIOSITY drive
2. Your AVR-IoT WG board will lose WiFi connection
3. Reset your board by unplugging it and plugging it back in 
4. Navigate back to the CURIOSITY drive, and click on the CLICK-ME.htm
5. Follow the instructions to configure a WIFI.CFG file, and drag and drop it into the CURIOSITY drive
